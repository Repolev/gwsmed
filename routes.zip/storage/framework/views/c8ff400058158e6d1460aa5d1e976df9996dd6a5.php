<?php $__env->startSection('content'); ?>
    <div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-lg-6 col-md-8 col-sm-12">
                        <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>Edit Product</h2>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>"><i class="icon-home"></i></a></li>
                            <li class="breadcrumb-item">Products</li>
                            <li class="breadcrumb-item active">Edit Product</li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="row clearfix">
                <div class="col-md-12">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="card">
                        <div class="body">
                            <form action="<?php echo e(route('product.update',$product->id)); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('patch'); ?>
                                <div class="row clearfix">
                                    <div class="col-lg-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Title <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" placeholder="Title" name="title" value="<?php echo e(ucfirst($product->title)); ?>" id="productTitle">
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12">
                                        <div class="form-group">
                                        <label for="">Product URL<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" placeholder="product-slug" name="slug" value="<?php echo e($product->slug); ?>" id="productSlug">
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Model no. <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" placeholder="Model number" name="model_no" value="<?php echo e($product->model_no); ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Summary <span class="text-danger">*</span></label>
                                            <textarea id="summary" class="form-control" placeholder="Some text..." name="summary" ><?php echo e($product->summary); ?></textarea>
                                        </div>
                                    </div>


                                    <div class="col-lg-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Description</label>
                                            <textarea id="description" class="form-control description" placeholder="Write some text..." name="description"><?php echo e($product->description); ?></textarea>
                                        </div>
                                    </div>

                                    














                                    <?php
                                        $photo=explode(',',$product->image_path);
                                    ?>

                                    <div class="col-lg-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Photo</label>
                                            <input type="file" name="photo[]" multiple class="dropify" data-height="150" data-default-file="<?php echo e(asset($photo[0])); ?>" value="<?php echo e(asset($photo[0])); ?>">
                                        </div>
                                    </div>

















                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <label for="">Categories/SubCategories</label>
                                        <select id="categoryId" name="category_id[]" class="form-control show-tick select2" multiple>

                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($cat->id); ?>" <?php echo e(in_array($cat->id, $product_categories->pluck('category_id')->toArray()) ? "selected" : ""); ?>><?php echo e($cat->title); ?></option>
                                                        <?php if(count($cat->subcategories)>0): ?>
                                                                <?php $__currentLoopData = $cat->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($subCat->id); ?>" <?php echo e(in_array($subCat->id, $product_categories->pluck('category_id')->toArray()) ? "selected" : ""); ?>><?php for($i = 0; $i <= $cat->level; $i++): ?> - <?php endfor; ?><?php echo e($subCat->title); ?></option>
                                                                    <?php if(count($subCat->subcategories)>0): ?>
                                                                        <?php $__currentLoopData = $subCat->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub2Cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($sub2Cat->id); ?>" <?php echo e(in_array($sub2Cat->id, $product_categories->pluck('category_id')->toArray()) ? "selected" : ""); ?>><?php for($i = 0; $i <= $subCat->level; $i++): ?> - <?php endfor; ?><?php echo e($sub2Cat->title); ?></option>
                                                                            <?php if(count($sub2Cat->subcategories)>0): ?>
                                                                                <?php $__currentLoopData = $sub2Cat->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub3Cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <option value="<?php echo e($sub3Cat->id); ?>" <?php echo e(in_array($sub3Cat->id, $product_categories->pluck('category_id')->toArray()) ? "selected" : ""); ?>><?php for($i = 0; $i <= $sub2Cat->level; $i++): ?> - <?php endfor; ?><?php echo e($sub3Cat->title); ?></option>
                                                                                    <?php if(count($sub3Cat->subcategories)>0): ?>
                                                                                        <?php $__currentLoopData = $sub3Cat->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub4Cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                            <option value="<?php echo e($sub4Cat->id); ?>" <?php echo e(in_array($sub4Cat->id, $product_categories->pluck('category_id')->toArray()) ? "selected" : ""); ?>><?php for($i = 0; $i <= $sub3Cat->level; $i++): ?> - <?php endfor; ?><?php echo e($sub4Cat->title); ?></option>
                                                                                            <?php if(count($sub4Cat->subcategories)>0): ?>
                                                                                                <?php $__currentLoopData = $sub4Cat->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub5Cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                    <option value="<?php echo e($sub5Cat->id); ?>" <?php echo e(in_array($sub5Cat->id, $product_categories->pluck('category_id')->toArray()) ? "selected" : ""); ?>><?php for($i = 0; $i <= $sub4Cat->level; $i++): ?> - <?php endfor; ?><?php echo e($sub5Cat->title); ?></option>
                                                                                                    <?php if(count($sub5Cat->subcategories)>0): ?>
                                                                                                        <?php $__currentLoopData = $sub5Cat->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub6Cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                            <option value="<?php echo e($sub6Cat->id); ?>" <?php echo e(in_array($sub6Cat->id, $product_categories->pluck('category_id')->toArray()) ? "selected" : ""); ?>><?php for($i = 0; $i <= $sub5Cat->level; $i++): ?> - <?php endfor; ?><?php echo e($sub6Cat->title); ?></option>
                                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                    <?php endif; ?>
                                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                            <?php endif; ?>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    <?php endif; ?>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                        </select>
                                    </div>









                                    







                                    <div class="col-lg-12 col-md-12">
                                                <div class="form-group">
                                                    <label for="">Is featured : </label>
                                                    <input type="checkbox" name="is_featured" value="1" <?php echo e($product->is_featured==1 ? 'checked' : ''); ?> data-toggle="switchbutton"  data-size="sm">
        
                                                </div>
                                    </div>

                                    <div class="col-lg-12 col-md-12">
                                        <div class="form-group">
                                            <label for="imageAlt">Image Alt: </label>
                                            <input type="text" name="image_alt" class="form-control" placeholder="Image Alt" value="<?php echo e($product->image_alt); ?>">
                                        </div>
                                    </div>

                                    <div class="col-lg-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Meta Tags : </label>
                                            <input type="text" name="meta_tag" class="form-control" placeholder="Meta tags" value="<?php echo e($product->meta_tag); ?>">
                                            
                                        </div>
                                    </div>


                                    <div class="col-lg-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Meta Description : </label>
                                            <textarea  name="meta_description" class="form-control" placeholder="Meta Description" ><?php echo e($product->meta_description); ?></textarea>
                                            
                                        </div>
                                    </div>

                                    <div class="col-lg-12 col-sm-12">
                                        <label for="status">Status</label>
                                        <select name="status" class="form-control show-tick">
                                            <option value="active" <?php echo e($product->status=='active' ? 'selected' : ''); ?>>Active</option>
                                            <option value="inactive" <?php echo e($product->status == 'inactive' ? 'selected' : ''); ?> >Inactive</option>
                                        </select>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary">Update</button>
                                <button type="reset" class="btn btn-outline-secondary">Cancel</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>

    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <script>
        $(document).ready(function() {
            $('.select2').select2({
                placeholder:"Choose category subcategory.."
            });
        });
    </script>

    <script>
        $(document).ready(function() {
            $('.description').summernote();
        });
    </script>

    <script>
        $(document).ready(function() {
            $('#summary').summernote();
        });
        $("#productTitle").focusout(function(e){
            var productsTitle = $("#productTitle").val();
            var createdSlug = convertToSlug(productTitle.trim());
            var blogSlug = $("#productSlug").val(createdSlug);
        });

        function convertToSlug(Text){
            return Text
                .toLowerCase()
                .replace(/[^\w ]+/g,'')
                .replace(/ +/g,'-')
                ;
        }
    </script>
    <script>

        var child_cat_id=<?php echo e($product->child_cat_id); ?>;
        $('#cat_id').change(function(){
            var cat_id=$(this).val();

            if(cat_id !=null){
                $.ajax({
                    url:"/admin/category/"+cat_id+"/child",
                    type:"POST",
                    data:{
                        _token:"<?php echo e(csrf_token()); ?>",
                        cat_id:cat_id,
                    } ,
                    success:function(response){
                        var html_option="<option value=''>--- Child Category---</option>";
                        if(response.status){
                            $('#child_cat_div').removeClass('d-none');
                            $.each(response.data,function(id,title){
                                html_option +="<option value='"+id+"' "+(child_cat_id==id ? 'selected' : '')+">"+title+"</option>"
                            });
                        }
                        else{
                            $('#child_cat_div').addClass('d-none');
                        }
                        $('#chil_cat_id').html(html_option);
                    }
                });
            }
        });

        if(child_cat_id !=null){
            $('#cat_id').change();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gwsmedco/gws.gwsmed.com/resources/views/backend/product/edit.blade.php ENDPATH**/ ?>
<?php $__env->startComponent('mail::message'); ?>
Enquiry Form<br>
My name is, <?php echo e($details['full_name']); ?><br>
My contact number is: <?php echo e($details['phone']); ?>.<br>
Message: <?php echo e($details['message']); ?>.<br>
My address is: <?php echo e($details['address']); ?>.<br>
Categories:
<ul>
<?php $__currentLoopData = $details['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($category->title); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php $__env->startComponent('mail::button', ['url' => 'gws.gwsmed.com']); ?>
Click Here
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
Gwsmed
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH /home/gwsmedco/gws.gwsmed.com/resources/views/mail/category_enquiry.blade.php ENDPATH**/ ?>
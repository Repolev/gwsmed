<?php $__env->startSection('content'); ?>

    <!-- breadcrumb start -->
    <div class="cv-breadcrumb">
    </div>
    <div class="row py-2" style="border-bottom: 1px solid #f5f5f5;">
        <div class="container">
            <div class="col-12">
                <div class="cv-breadcrumb-box">
                    <ul>
                        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        |
                        <li>Blog</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- breadcrumb end -->
    <!-- blog start -->
    <div class="cv-blog-page my-3">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="title py-3">
                        <h4>Blogs</h4>
                    </div>
                    <div class="cv-blog-page-box">
                        <div class="row">
                            <?php if(count($blogs)>0): ?>
                                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4">
                                        <div class="cv-blog-box">
                                            <div class="cv-blog-img">
                                                <img src="<?php echo e(asset($blog->image_path)); ?>" alt="<?php echo e($blog->title); ?>" class="img-fluid"/>
                                            </div>
                                            <div class="cv-blog-data">
                                                <div class="d-flex">
                                                    <a href="#" class="cv-blog-date"> <i class="fa fa-clock"></i> <?php echo e(\Carbon\Carbon::parse($blog->created_at)->format('d M Y')); ?></a>
                                                </div>
                                                <a href="<?php echo e(route('blog.detail',$blog->slug)); ?>" class="cv-blog-title"><?php echo e(ucfirst($blog->title)); ?></a>

















                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <p class="text-center">No blog found</p>
                            <?php endif; ?>

                            <div class="col-md-12 my-5">
                                <?php echo e($blogs->links('vendor.pagination.custom')); ?>











                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- blog end -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gwsmedco/gws.gwsmed.com/resources/views/frontend/pages/blog.blade.php ENDPATH**/ ?>
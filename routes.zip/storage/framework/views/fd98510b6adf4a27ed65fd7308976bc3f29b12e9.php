    <!-- footer start -->
    <div class="cv-footer spacer-top">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="cv-foot-box cv-foot-logo">
                        <?php if(\App\Models\Setting::value('footer_logo')): ?>
                            <img src="<?php echo e(asset('storage/frontend/images/settings/'.\App\Models\Setting::value('footer_logo'))); ?>" style="max-width: 200px" alt="image" class="img-fluid"/>
                        <?php else: ?>
                            <img src="<?php echo e(Helper::defaultLogo()); ?>" alt="image" class="img-fluid" style="max-width: 200px" />
                        <?php endif; ?>
                        <p><?php echo e(\Illuminate\Support\Str::limit(\App\Models\Setting::value('short_intro'),150)); ?></p>

                    </div>
                </div>
                <div class="col-lg-2 col-md-6">
                    <div class="cv-foot-box cv-foot-links">
                        <h2>Categories</h2>
                        <?php
                            $categories=\App\Models\Category::with('subcategories')->where(['status'=>'active'])->where('on_menu', 1)->latest()->limit(4)->get();
                        ?>
                        <ul>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('product.category.0', $category->slug)); ?>"><?php echo e($category->title); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6">
                    <div class="cv-foot-box cv-foot-links">
                        <h2>Useful links</h2>
                        <ul>
                            <li><a href="<?php echo e(route('about.us')); ?>">About</a></li>
                            <li><a href="<?php echo e(route('contact.us')); ?>">Contact Us</a></li>
                            <li><a href="<?php echo e(route('certification')); ?>">Certification</a></li>
                            <li><a href="<?php echo e(route('infrastructure')); ?>">Infrastructure</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="cv-foot-box cv-foot-contact">
                        <h2>Contact</h2>
                        <p><span>Contact : </span><?php echo e(\App\Models\Setting::value('phone')); ?></p>
                        <p><span>Email : </span><?php echo e(\App\Models\Setting::value('email')); ?></p>
                        <p><span>Address : </span><?php echo e(\App\Models\Setting::value('address')); ?></p>
                        <ul class="cv-foot-social">
                            <li><a href="https://facebook.com/<?php echo e(\App\Models\Setting::value('facebook')); ?>">
                                   <img src="<?php echo e(asset('frontend/assets/images/facebook.svg')); ?>">
                                </a></li>
                            <li><a href="https://twitter.com/<?php echo e(\App\Models\Setting::value('twitter')); ?>">
                                    <img src="<?php echo e(asset('frontend/assets/images/twitter.svg')); ?>">
                                </a></li>
                            <li><a href="https://instagram.com/<?php echo e(\App\Models\Setting::value('instagram')); ?>">
                                  <img src="<?php echo e(asset('frontend/assets/images/instagram.svg')); ?>">
                                </a></li>
                                
                                <li><a style="background:transparent;" href="https://www.linkedin.com/<?php echo e(\App\Models\Setting::value('linkedin')); ?>">
                                  <img src="<?php echo e(asset('frontend/assets/images/linkedin.png')); ?>">
                                </a></li>
                                
                                 <li><a href="https://www.youtube.com/<?php echo e(\App\Models\Setting::value('youtube')); ?>">
                                  <img src="<?php echo e(asset('frontend/assets/images/youtube.png')); ?>">
                                </a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- footer end -->
    <!-- copyright start -->
    <div class="cv-copyright" style="background: #AB292B">
        <div class="container">
            <div class="row">
                <div class="col-md-12 d-flex align-items-center justify-content-center text-white">
                    <p>&copy; <?php echo e(\App\Models\Setting::value('footer')); ?></p> | 
                    <p><a href="<?php echo e(route ('privacy.disclaimer')); ?>">Privacy Policy</a></p> |
                    <p><a href="#">Disclaimer</a></p> 
                </div>
            </div>
        </div>
    </div>
    <!-- copyright end -->


    <!-- Go To Top Button -->
    <button class="scrollToTopBtn"><i class="fas fa-angle-double-up"></i></button>
    <footer></footer>
    <!-- Go To Top end -->

    <!-- Cookies -->
    <div class="accept-cookies">
        <?php echo $__env->make('cookieConsent::index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

</div>
<!-- main wrapper end -->

<!-- Share this end -->
<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5df0f9489d176625"></script>


<!-- Share this end -->
<style>
    .atss-top{
        display: none;
    }
</style><?php /**PATH /home/gwsmedco/gws.gwsmed.com/resources/views/frontend/layouts/footer.blade.php ENDPATH**/ ?>
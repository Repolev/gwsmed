<!DOCTYPE html>
<html lang="en">

<head>
   <?php echo $__env->make('frontend.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo toastr_css(); ?>
</head>

<style>
    .cv-heading {
        text-align: center;
        max-width: 650px;
        margin: 0 auto 43px;
    }

    .cv-heading h1 {
        font-size: 28px;
        font-weight: 600;
        color: #AB292B;
        margin-bottom: 5px;
        text-transform: capitalize;
    }

    .border-bottom-line {
        width: 12%;
        height: 3px;
        background-color: #AB292B;
        border-radius: 4px;
    }

    ul.catalog-list {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        grid-auto-rows: 24rem;
        column-gap: 2rem;
        list-style: none;
    }

    ul.catalog-list li a h1 {
        font-size: 16px;
        margin-top: 2rem;
        font-weight: 500;
        color: #000;
    }

    ul.catalog-list li a h1:hover {
        color: #AB292B;
        cursor: pointer;
    }



    ul.catalog-list li a img {
        transition: all 0.3s linear;
    }

    ul.catalog-list li a img:hover {
        transform: scale(1.1);
        cursor: pointer;
    }
</style>

<body>

    <?php
        use App\Models\Setting;$settings=Setting::first();
    ?>

    <!-- preloader start -->
    <div class="cv-ellipsis">
        <div class="cv-preloader">
            <div></div>
        </div>
    </div>
    <!-- preloader end -->
    <!-- main wrapper start -->
    <div class="cv-main-wrapper">

        <div id="header">
            <?php echo $__env->make('frontend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <?php echo $__env->yieldContent('content'); ?>


        <!-- footer start -->
        <?php echo $__env->make('frontend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- footer end -->

    </div>

    <?php echo $__env->make('frontend.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo toastr_js(); ?>
    <?php echo app('toastr')->render(); ?>
</body>

</html>
<?php /**PATH /home/gwsmedco/gws.gwsmed.com/resources/views/frontend/layouts/master.blade.php ENDPATH**/ ?>
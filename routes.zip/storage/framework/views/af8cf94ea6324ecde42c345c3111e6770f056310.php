<?php $__env->startSection('content'); ?>
    <div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Products
                            <a class="btn btn-sm btn-outline-secondary" href="<?php echo e(route('product.create')); ?>"><i class="icon-plus"></i> Add Product</a></h2>
                        <ul class="breadcrumb float-left">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>"><i class="icon-home"></i></a></li>
                            <li class="breadcrumb-item active">Product</li>
                        </ul>
                        <p class="float-right">Total Products :<?php echo e(\App\Models\Product::count()); ?></p>
                    </div>
                </div>
            </div>

            <div class="row clearfix">
                <div class="col-lg-12">
                    <?php echo $__env->make('backend.layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="header">
                            <div class="row">
                                <div class="col-md-6">
                                    <h2><strong>Product</strong> List</h2>
                                </div>
                                <div class="col-md-6 d-none" id="category_lists">
                                    <form action="<?php echo e(route('product.bulk.categories')); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                    <select id="categoryId" name="category_id[]" class="form-control select2  show-tick" multiple>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->title); ?></option>
                                            <?php if(count($cat->subcategories)>0): ?>
                                                <?php $__currentLoopData = $cat->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($subCat->id); ?>"><?php for($i = 0; $i <= $cat->level; $i++): ?> - <?php endfor; ?><?php echo e($subCat->title); ?></option>
                                                    <?php if(count($subCat->subcategories)>0): ?>
                                                        <?php $__currentLoopData = $subCat->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub2Cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($sub2Cat->id); ?>"><?php for($i = 0; $i <= $subCat->level; $i++): ?> - <?php endfor; ?><?php echo e($sub2Cat->title); ?></option>

                                                            <?php if(count($sub2Cat->subcategories)>0): ?>
                                                                <?php $__currentLoopData = $sub2Cat->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub3Cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($sub3Cat->id); ?>"><?php for($i = 0; $i <= $sub2Cat->level; $i++): ?> - <?php endfor; ?><?php echo e($sub3Cat->title); ?></option>
                                                                    <?php if(count($sub3Cat->subcategories)>0): ?>
                                                                        <?php $__currentLoopData = $sub3Cat->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub4Cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($sub4Cat->id); ?>"><?php for($i = 0; $i <= $sub3Cat->level; $i++): ?> - <?php endfor; ?><?php echo e($sub4Cat->title); ?></option>
                                                                            <?php if(count($sub4Cat->subcategories)>0): ?>
                                                                                <?php $__currentLoopData = $sub4Cat->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub5Cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <option value="<?php echo e($sub5Cat->id); ?>"><?php for($i = 0; $i <= $sub4Cat->level; $i++): ?> - <?php endfor; ?><?php echo e($sub5Cat->title); ?></option>
                                                                                    <?php if(count($sub5Cat->subcategories)>0): ?>
                                                                                        <?php $__currentLoopData = $sub5Cat->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub6Cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                            <option value="<?php echo e($sub6Cat->id); ?>"><?php for($i = 0; $i <= $sub5Cat->level; $i++): ?> - <?php endfor; ?><?php echo e($sub6Cat->title); ?></option>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    <?php endif; ?>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <input type="hidden" name="products" id="bulkProducts">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                    </form>
                                </div>
                            </div>

                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                    <thead>
                                    <tr>
                                        <th></th>
                                        <th>S.N.</th>

                                        <th>Title</th>
                                        <th>Photo</th>
                                        <th>Categories</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $photo=explode(',',$item->image_path);
                                        ?>
                                        <tr>
                                            <td><input type="checkbox" id="check_<?php echo e($item->id); ?>" class="productCheck" value="<?php echo e($item->id); ?>"></td>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e(ucfirst($item->title)); ?></td>
                                            <td>
                                                <img src="<?php echo e(asset($photo[0])); ?>" alt="Product image" style="max-height: 90px; max-width: 120px">
                                            </td>
                                            <td><?php $__currentLoopData = $item->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($category->title); ?> | <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                                            <td>
                                                <input type="checkbox" name="toggle" value="<?php echo e($item->id); ?>" data-toggle="switchbutton" data-size="sm" <?php echo e($item->status=='active' ? 'checked' : ''); ?>>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('product.detail',$item->slug)); ?>" target="_blank" data-toggle="tooltip" title="view" class="mr-1 float-left btn btn-sm btn-outline-info" data-placement="bottom"><i class="fas fa-eye"></i> </a>
                                                <a href="<?php echo e(route('product.edit',$item->id)); ?>" data-toggle="tooltip" title="edit" class="float-left btn btn-sm btn-outline-warning" data-placement="bottom"><i class="fas fa-edit"></i> </a>
                                                <form class="float-left ml-1" action="<?php echo e(route('product.destroy',$item->id)); ?>"  method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <a href="" data-toggle="tooltip" title="delete" data-id="<?php echo e($item->id); ?>" class="dltBtn btn btn-sm btn-outline-danger" data-placement="bottom"><i class="fas fa-trash-alt"></i> </a>
                                                </form>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $('.productCheck').click(function(){
            let arrayNew = [];
            var oldValue = $("#bulkProducts").val();
            var newValue = $(this).val();
            if(oldValue != ''){
                arrayNew.push(oldValue);
            }
            arrayNew.push(newValue);
            console.log(arrayNew);
            $('#bulkProducts').val(arrayNew);
            if($(this).prop("checked")==true){
                $('#category_lists').removeClass('d-none');
            }
        })
    </script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $('.dltBtn').click(function (e) {
            var form=$(this).closest('form');
            var dataID=$(this).data('id');
            e.preventDefault();
            swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this imaginary file!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
                .then((willDelete) => {
                    if (willDelete) {
                        form.submit();
                        swal("Poof! Your imaginary file has been deleted!", {
                            icon: "success",
                        });
                    } else {
                        swal("Your imaginary file is safe!");
                    }
                });

        });
    </script>
    
    <script>
        $('input[name=toggle]').change(function () {
            var mode=$(this).prop('checked');
            var id=$(this).val();
            // alert(id);
            $.ajax({
                url:"<?php echo e(route('product.status')); ?>",
                type:"POST",
                data:{
                    _token:'<?php echo e(csrf_token()); ?>',
                    mode:mode,
                    id:id,
                },
                success:function (response) {
                    if(response.status){
                        console.log(response.msg);
                    }
                    else{
                        alert('Please try again!');
                    }
                }
            })
        });
    </script>

    
    <script>
        $('input[name=deal]').change(function () {
            var mode=$(this).prop('checked');
            var id=$(this).val();
            $.ajax({
                url:"<?php echo e(route('todays.deal')); ?>",
                type:"POST",
                data:{
                    _token:'<?php echo e(csrf_token()); ?>',
                    mode:mode,
                    id:id,
                },
                success:function (response) {
                    if(response.status){
                        console.log(response.msg);
                    }
                    else{
                        alert('Please try again!');
                    }
                }
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gwsmedco/gws.gwsmed.com/resources/views/backend/product/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i
                                    class="fa fa-arrow-left"></i></a> Order</h2>
                        <ul class="breadcrumb float-left">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>"><i class="icon-home"></i></a></li>
                            <li class="breadcrumb-item active">Order detail</li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="row clearfix">
                <div class="col-lg-12">
                    <?php echo $__env->make('backend.layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="body">
                            <div class="row">
                                <div class="col-xl-12 col-md-12">
                                    <div class="card">
                                        <div class="invoice-content">
                                            <div class="row">
                                                <div class="col-lg-6 col-sm-6">
                                                    <div class="ordr-date">
                                                        <h2>Invoice</h2>
                                                        <b>Order</b> #<?php echo e($order->order_number); ?><br>

                                                        <b>Order Date :</b> <?php echo e(\Carbon\Carbon::parse($order->created_at)->format('d M Y')); ?>

                                                    </div>
                                                </div>
                                                <div class="col-lg-6 col-sm-6">
                                                    <div class="float-right">
                                                        <b>Shipping Address :</b><br>
                                                        <?php echo e($order->address); ?><br>
                                                        <?php echo e($order->address2); ?><br>
                                                        <?php echo e($order->state); ?><br>
                                                        <?php echo e($order->country); ?>,
                                                        <?php echo e($order->ip_address); ?>,
                                                        <?php echo e($order->postcode); ?><br>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12">
                                                    <div class="card card-static-2 mb-30 mt-3">
                                                        <div class="card-body-table">
                                                            <div class="table-responsive">
                                                                <table class="table table-striped table-hover">
                                                                    <thead class="thead-info">
                                                                    <tr>
                                                                        <th style="width:130px">S.N.</th>
                                                                        <th>Item</th>
                                                                        <th style="width:150px" class="text-center">Image</th>
                                                                        <th style="width:150px" class="text-center">Qty</th>
                                                                    </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                    <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php
                                                                            $image=explode(',',$item->image_path);
                                                                        ?>
                                                                    <tr>
                                                                        <td><?php echo e($loop->iteration); ?></td>
                                                                        <td>
                                                                            <p><?php echo e(ucfirst($item->title)); ?></p>
                                                                        </td>
                                                                        <td class="text-center"><img src="<?php echo e(asset($image[0])); ?>" style="max-width: 100px"></td>
                                                                        <td class="text-center"><?php echo e($item->pivot->quantity); ?></td>
                                                                    </tr>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-8"></div>
                                                <div class="col-lg-4">
                                                    <table class="table">
                                                        <form action="<?php echo e(route('order.status')); ?>" id="order-status" method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
                                                            <tr>
                                                                <td><b>Status <span class="text-danger">*</span></b> : </td>
                                                                <td style="display: grid">
                                                                    <select class="form-control" name="condition" id="">
                                                                        
                                                                        <?php if($order->condition=='process' || $order->condition=='delivered' || $order->condition=='cancelled' ): ?>
                                                                            <option disabled value="pending" <?php echo e($order->condition=='pending' ? 'selected' : ''); ?>>Pending</option>
                                                                        <?php else: ?>
                                                                            <option value="pending" <?php echo e($order->condition=='pending' ? 'selected' : ''); ?>>Pending</option>
                                                                        <?php endif; ?>

                                                                        
                                                                        <?php if($order->condition=='delivered' || $order->condition=='cancelled' ): ?>
                                                                            <option disabled value="process" <?php echo e($order->condition=='process' ? 'selected' : ''); ?>>Process</option>
                                                                        <?php else: ?>
                                                                            <option value="process" <?php echo e($order->condition=='process' ? 'selected' : ''); ?>>Process</option>
                                                                        <?php endif; ?>

                                                                        
                                                                        <?php if($order->condition=='cancelled' ): ?>
                                                                            <option disabled value="delivered" <?php echo e($order->condition=='delivered' ? 'selected' : ''); ?>>Delivered</option>
                                                                        <?php else: ?>
                                                                            <option value="delivered" <?php echo e($order->condition=='delivered' ? 'selected' : ''); ?>>Delivered</option>
                                                                        <?php endif; ?>

                                                                        
                                                                        <?php if($order->condition=='delivered'): ?>
                                                                            <option disabled value="cancelled" <?php echo e($order->condition=='cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                                                                        <?php else: ?>
                                                                            <option value="cancelled" <?php echo e($order->condition=='cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                                                                        <?php endif; ?>
                                                                    </select>
                                                                    <button id="status_btn" class="btn btn-sm btn-success">Update</button>
                                                                </td>
                                                            </tr>

                                                        </form>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $('#status_btn').click(function () {
            $('#status_btn').html('<i class="fas fa-spinner fa-spin"></i> Updating..');
            $('#order-status').submit();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gwsmedco/gws.gwsmed.com/resources/views/backend/order/show.blade.php ENDPATH**/ ?>
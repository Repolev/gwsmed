1.) Menu bar:- We will display all divisions on menu bar itself 
 a.) General Medical Division
 b.) Orthopaedic Division
 c.) Ophthalmic Division
 d.) Covid 19 Products - *new
On menu bar right side link to E-catalogue, which will link on catalogue page.

2.) On category/Sub category and product page color line under the name of main category


For allowing cookie need to scroll down, it should come when Website open as sticky bar

4.) Product details page
 a.) We need to fix product image size, whatever we upload should automatically convert into fix size. ( Mostly we will upload the fix size only)
 b.) Need outer box for the main product picture showing
 c.) Breadcrumbs
 d.) product model and category should be in bold, there should be comma between the category names coming
e.) Send an enquiry and bulk enquiry cart button should be near to each other ( enquiry form below is not okay)
 f.) Description area need to conver into box with line
 g.) Related products should come below into cover box like gpc
h.) Social media sharing option below the summary
[1:40 pm, 06/04/2021] AB: 5.) Area size for logo upload should be bigger in width

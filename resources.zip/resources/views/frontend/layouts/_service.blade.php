<section class="section-bg pt-5 pb-5">
    <div class="container">
        <div class="row no-gutters">
            <div class="col-lg-4 icon-box-wrapper">
                <div class="icon_box icon_box_style1">
                    <div class="icon">
                        <img src="frontend/images/icons/like.png" alt="">
                    </div>
                    <div class="icon_box_content">
                        <h5>Quality Checked</h5>
                        <p>If you are going to use of Lorem, you need to be sure there anything</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 icon-box-wrapper">
                <div class="icon_box icon_box_style1">
                    <div class="icon">
                        <img src="frontend/images/icons/monitoring.png" alt="">
                    </div>
                    <div class="icon_box_content">
                        <h5>Best Service</h5>
                        <p>If you are going to use of Lorem, you need to be sure there anything</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 icon-box-wrapper">
                <div class="icon_box icon_box_style1">
                    <div class="icon">
                        <img src="frontend/images/icons/customer-support.png" alt="">
                    </div>
                    <div class="icon_box_content">
                        <h5>Excellent 27/4 Support</h5>
                        <p>If you are going to use of Lorem, you need to be sure there anything</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
